<?php

// Food theme basic functions
function food_theme_basic_fun(){

	//transalition link
	load_theme_textdomain('', get_template_directory().'/language');

	//add theme supports
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('menus');
	add_theme_support('custom-header');
	add_theme_support('custom-background');
	add_theme_support('woocommerce');



	// register menus
	register_nav_menus(array(
		'main-menu'           => __('Main Menu', ''),
		'footer-menu'         => __('Footer Menu', '')
	));


	function read_more($limit){
		$post_content = explode(" ", get_the_content());
		$less_content = array_slice($post_content, 0, $limit);
		echo implode(" ", $less_content);
	}


	//sliders register
	register_post_type('foodslider', array(
		'labels'           => array(
			'name'       => 'Sliders',
             'add_new_item'      => 'Please Add Sliders'
		),
		'public'         => true,
		'supports'       => array('title', 'editor', 'thumbnail')
	));

	register_post_type('foodsblocks1', array(
		'labels'           => array(
			'name'       => 'Blocks',
             'add_new_item'      => 'Please Add Blocks'
		),
		'public'         => true,
		'supports'       => array('title', 'editor', 'thumbnail')
	));







}
add_action('after_setup_theme', 'food_theme_basic_fun');



// sidebar section
function food_right_sidebar(){
	//right sidebar
	register_sidebar(array(
		'name'          => __('Right Sidebar', 'food'),
		'description'   => __('Add your right sidebar widgets here', 'food'),
		'id'            => 'right-sidebar',
		'before-widget' => '<div class="widget">',
		'after-widget' => '</div></div>',
		'before-title' => '<div class="wid-header"><h5>',
		'after-title' => '</h5></div><div class="wid-content">',
	));

	//footer sidebar
	register_sidebar(array(
		'name'          => __('Footer Widgets', 'food'),
		'description'   => __('Add your footer widgets here', 'food'),
		'id'            => 'footer-widget',
		'before-widget' => '<div class="col-1-3"><div class="wrap-col"><h4>',
		'after-widget' => '</div></div></h4>',
		'before-title' => '<div class="row"><h5>',
		'after-title' => '</div></h5>'
	));




}
add_action('widgets_init', 'food_right_sidebar');


// add redux theme options
require_once('lib/redux-core/framework.php');
require_once('lib/sample/sample-config.php');


//add cmb2

require_once('cmb/init.php');
require_once('cmb/sohel.php');

//menu walker link
require_once('menu-amar.php');



// different style link here

function food_theme_link(){
	wp_enqueue_style('zerogrid', get_template_directory_uri(). '/css/zerogrid.css');
	wp_enqueue_style('style', get_template_directory_uri(). '/css/style.css');
	wp_enqueue_style('slide', get_template_directory_uri(). '/css/slide.css');
	wp_enqueue_style('menu', get_template_directory_uri(). '/css/menu.css');
	wp_enqueue_style('awesome', get_template_directory_uri(). '/font-awesome/css/font-awesome.min.css');



	//jquery link
	wp_enqueue_script('jquery');
	wp_enqueue_script('demo', get_template_directory_uri(). '/js/demo.js', array('jquery'), true, true);
	wp_enqueue_script('classie', get_template_directory_uri(). '/js/classie.js', array('jquery'), true, true);
	wp_enqueue_script('responsiveslides', get_template_directory_uri(). '/js/responsiveslides.min.js', array('jquery'), true, true);
	wp_enqueue_script('custom', get_template_directory_uri(). '/js/custom.js', array('jquery'), true, true);
	

}
add_action('wp_enqueue_scripts', 'food_theme_link');
















?>