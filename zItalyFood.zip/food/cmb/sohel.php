<?php


function cmb2_member_box(){
	$sohel = new_cmb2_box(array(
		'title'      => 'Member Box',
		'id'         => $prefix . 'metabox',
		'object_types' => array('page')

	));

	$sohel-> add_field(array(
		'name'      => 'Member Name',
		'desc'      => 'File Description',
		'id'        => $prefix .'text',
		'type'      => 'text'
	));


	$sohel = new_cmb2_box(array(
		'title'           => 'Member Social Link',
		'id'              => 'msl',
		'desc'            => 'type member name',
		'object_types'    => array('page')
	));

}
add_action('cmb2_init', 'cmb2_member_box');

















?>