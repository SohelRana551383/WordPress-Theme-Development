<?php get_header(); ?>

<!--////////////////////////////////////Container-->
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="archive.html">Blog</a></li>
			</ul>
		</div>
		<div id="main-content" class="col-2-3">
			<div class="wrap-content">

             <?php
               $art_header = new WP_Query(

               )
             ?>
			<?php while(have_posts()) : the_post(); ?>
				<article>
					<div class="art-header">
						<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></a>
						<div class="info"><?php the_author(); ?> on <?php the_date('F,d,y'); ?> in: <a href="<?php the_permalink(); ?>">Event</a></div>
					</div>
					<div class="art-content">
						<?php the_post_thumbnail(); ?>
						<p><?php read_more(56); ?></p>
					</div>
					<a class="button button02" href="<?php the_permalink(); ?>">MORE</a>
				</article>
			<?php endwhile; ?>
				

				
			</div>
		</div>
		<div id="sidebar" class="col-1-3">
			<div class="wrap-sidebar">
				<!---- Start Widget ---->
				<?php dynamic_sidebar('right-sidebar'); ?>
			</div>
		</div>
	</div>
</section>

<!--////////////////////////////////////Footer-->
<?php get_footer(); ?>