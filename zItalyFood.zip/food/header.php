<?php global $sohel1122; ?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html <?php language_attributes(); ?>> <!--<![endif]-->

<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="<?php bloginfo('charset'); ?>">
	
	<meta name="description" content="Free Responsive Html5 Css3 Templates | zerotheme.com">
	<meta name="author" content="www.zerotheme.com">
	
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
  	
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo esc_url(get_template_directory_uri()); ?>/<?php echo $sohel1122['res']; ?>">

	<!-- Custom Fonts -->
    
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<script src="js/css3-mediaqueries.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
    
</head>
<body <?php body_class(); ?>>
<div class="layout"  style="width: <?php echo $sohel1122['ly']; ?>; margin:auto;">
<div class="wrap-body">
	<!--///////////////////////////////////////Top-->
	<div class="top">
		<div class="zerogrid">
			<ul class="number f-left">
				<li class="mail"><p><?php echo $sohel1122['emm']; ?></p></li>
				<li class="phone"><p><?php echo $sohel1122['pnn']; ?></p></li>
			</ul>
			<ul class="top-social f-right">
				<?php if(esc_url($sohel1122['tw'])) : ?>
				<li><a href="<?php echo esc_url($sohel1122['tw']); ?>"><i class="fa fa-twitter"></i></a></li>
			    <?php endif; ?>

                <?php if(esc_url($sohel1122['fb'])) : ?>
				<li><a href="<?php echo esc_url($sohel1122['fb']); ?>"><i class="fa fa-facebook"></i></a></li>
				<?php endif; ?>

                <?php if(esc_url($sohel1122['gl'])) : ?>
				<li><a href="<?php echo esc_url($sohel1122['gl']); ?>"><i class="fa fa-google-plus"></i></a></li>
				<?php endif; ?>

                <?php if(esc_url($sohel1122['ln'])) : ?>
				<li><a href="<?php echo esc_url($sohel1122['ln']); ?>"><i class="fa fa-linkedin"></i></a></li>
				<?php endif; ?>

                <?php if(esc_url($sohel1122['in'])) : ?>
				<li><a href="<?php echo esc_url($sohel1122['in']); ?>"><i class="fa fa-instagram"></i></a></li>
				<?php endif; ?>
			</ul>
		</div>
	</div>
	<!--////////////////////////////////////Header-->
	<header>
		<div class="zerogrid">
			<center><div class="logo"><img src="<?php echo $sohel1122['lu']['url']; ?>" style="width: <?php echo $sohel1122['lw']; ?>; height: <?php echo $sohel1122['lh']; ?>;" ></div></center>
		</div>
	</header>
	<div class="site-title">
		<div class="zerogrid">
			<div class="row">
				<h2 class="t-center">Truely I am the best web devoloper in The Bangladesh</h2>
			</div>
		</div>
	</div>
    <!--//////////////////////////////////////Menu-->
    <a href="#" class="nav-toggle">Toggle Navigation</a>
    <nav class="cmn-tile-nav">
		<!--<ul class="clearfix">
			<li class="colour-1"><a href="index.html">Home</a></li>
			<li class="colour-2"><a href="menu.html">Menu</a></li>
			<li class="colour-3"><a href="location.html">Location</a></li>
			<li class="colour-4"><a href="archive.html">Blog</a></li>
			<li class="colour-5"><a href="reservation.html">Reservation</a></li>
			<li class="colour-6"><a href="staff.html">Our Staff</a></li>
			<li class="colour-7"><a href="news.html">News</a></li>
			<li class="colour-8"><a href="gallery.html">Gallery</a></li>
		</ul>-->
		<?php
		  wp_nav_menu(array(
		  	'theme_location'             => 'main-menu',
		  	'menu_class'                 => 'clearfix',
		  	'walker'                     => new ama_walker()

		  ));


		?>


    </nav>
