<div class="wrap-col">
	<?php dynamic_sidebar('right-sidebar'); ?>
</div>