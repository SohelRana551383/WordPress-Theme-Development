<?php

function zboom_default_functions(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('custom-background');


	load_theme_textdomain('zboom', get_template_directory_uri(). '/language');


	if (function_exists('register_nav_menu')){
		register_nav_menu('main-menu', __('Main Menu', 'zboom'));
		
	}

	register_post_type('zboomslider', array(

            'labels' => array(
                'name' => 'Sliders',
                'add_new_item' => __('Add New Slider', 'zboom')
            ),
            'public' => true,
            'supports' => array('title', 'thumbnail')
	));

	register_post_type('zboomservices', array(
          
          'labels' => array(
          	'name' => 'Blocks',
          	'add_new_item' => __('Add New Blocks', 'zboom')
          ),
          'public' => true,
           'supports' => array('title', 'editor')
	));

	register_post_type('zboomgallery', array(
          
          'labels' => array(
          	'name' => 'Gallery',
          	'add_new_item' => __('Add New Gallery Item', 'zboom')
          ),
          'public' => true,
           'supports' => array('title', 'editor', 'thumbnail')
	));


	function read_more($limit){
		$post_commet = explode(" ", get_the_content());
		$less_content = array_slice($post_commet, 0, $limit);
		echo implode(" ", $less_content);
	}



} 
add_action('after_setup_theme', 'zboom_default_functions');


require_once('libs/ReduxCore/framework.php');
require_once('libs/sample/sample-config.php');
require_once('shortcort.php');



function zboom_css_and_js(){
	wp_register_style('zerogrid', get_template_directory_uri().'/css/zerogrid.css');
	wp_register_style('style', get_template_directory_uri().'/css/style.css');
	wp_register_style('responsive', get_template_directory_uri().'/css/responsive.css');
	wp_register_style('responsiveslides', get_template_directory_uri().'/css/responsiveslides.css');





	wp_register_script('responsiveslides', get_template_directory_uri().'/js/responsiveslides.js');
	wp_register_script('jquery', get_template_directory_uri().'/js/jquery.js');





	
	wp_enqueue_style('zerogrid');
	wp_enqueue_style('style');
	wp_enqueue_style('responsive');
	wp_enqueue_style('responsiveslides');
	



	wp_enqueue_script('jquery');
	wp_enqueue_script('responsiveslides');
	wp_enqueue_script('jquery');



}
add_action('wp_enqueue_scripts','zboom_css_and_js');






function zboom_right_sidebar(){
	register_sidebar(array(
		'name' => __('Right Sidebar', 'zboom'),
		'description' => __('Add your right sidebar widgets here', 'zboom'),
		'id' => 'right-sidebar',
		'before_widget' => '<div class="box right-sidebar">',
		'after_widget' => '</div></div>',
		'before_title' => '<div class="heading"><h2>',
		'after_title' => '</h2></div><div class="content">',
	));

	register_sidebar(array(
		'name' => __('Contact Right Sidebar', 'zboom'),
		'description' => __('Add your Contact right sidebar widgets here', 'zboom'),
		'id' => 'contact-sidebar',
		'before_widget' => '<div class="box right-sidebar">',
		'after_widget' => '</div></div>',
		'before_title' => '<div class="heading"><h2>',
		'after_title' => '</h2></div><div class="content">',
	));

	register_sidebar(array(
		'name' => __('Footer Widgets', 'zboom'),
		'description' => __('Add your Footer  widgets here', 'zboom'),
		'id' => 'footer_widgets',
		'before_widget' => '<div class="col-1-4"><div class="wrap-col"><div class="box">',
		'after_widget' => '</div></div></div></div>',
		'before_title' => '<div class="heading"><h2>',
		'after_title' => '</h2></div><div class="content">',
	));


    

}
add_action('widgets_init', 'zboom_right_sidebar');


















?>