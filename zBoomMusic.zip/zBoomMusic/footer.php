<?php global $sohel5513; ?>
<footer>
	<div class="wrap-footer zerogrid">
			<div class="row block09">

				 <?php dynamic_sidebar('footer_widgets'); ?>
				
			</div>
		
		<div class="row copyright">
			<p><?php echo $sohel5513['copyright-t']; ?></p>
		</div>
	</div>
</footer>



<?php wp_footer(); ?>

</body>
</html>